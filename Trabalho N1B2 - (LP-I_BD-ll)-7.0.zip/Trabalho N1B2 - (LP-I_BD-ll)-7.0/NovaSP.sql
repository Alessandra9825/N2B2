USE [Portal]

CREATE PROCEDURE spConsultaPorId_Cliente (
    @id INT,
    @tabela VARCHAR(100)) AS
BEGIN
    DECLARE @sql VARCHAR(100) = 'SELECT * FROM ' + @tabela + ' WHERE id_Cliente = ' + CAST(@id AS VARCHAR(MAX))
	EXEC(@sql)
END
GO