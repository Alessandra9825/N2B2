﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using EletroStar.Models.Principais;
using EletroStar.DAO.Principais;

namespace EletroStar.Controllers
{
	public class LoginController : PadraoController<LoginViewModel>
	{

	}
}
