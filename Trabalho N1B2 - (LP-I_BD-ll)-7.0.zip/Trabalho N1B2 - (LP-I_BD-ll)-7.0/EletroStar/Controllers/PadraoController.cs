﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EletroStar.DAO;
using EletroStar.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Http;
using EletroStar.DAO.Principais;
using EletroStar.Models.Principais;
using EletroStar.DAO.Secundarias;
using EletroStar.Models.Secundarias;

namespace EletroStar.Controllers
{
    public class PadraoController<T> : Controller where T : PadraoViewModel
    {
        protected PadraoDAO<T> DAO { get; set; }
        protected bool GeraProximoId { get; set; }

        public virtual IActionResult Index(string searchString)
        {

            var lista = DAO.Listagem();
            return View(lista);
        }
        
        public IActionResult Create(int id)
        {
            ViewBag.operacao = "I";
            T model = Activator.CreateInstance(typeof(T)) as T; //new Model();
            PreencheDadosParaView("I", model);
            return View("Form", model);
        }

        public IActionResult Conta(int id)
        {
            ClienteDAO dao = new ClienteDAO();
            ClienteViewModel cliente = dao.Consulta(Convert.ToInt32(HttpContext.Session.GetString("Id")));
            EstadoCivilDAO estadoDao = new EstadoCivilDAO();
            EstadoCivilViewModel estadoCivil = estadoDao.Consulta(cliente.id_EstadoCivil);
            ViewBag.estadoCivil = estadoCivil.descricao;
            if (cliente.genero == 'M')
                ViewBag.genero = "Masculino";
            else if (cliente.genero == 'F')
                ViewBag.genero = "Feminino";
            EnderecoDAO enderecoDao = new EnderecoDAO();
            List<EnderecoViewModel> endereco = enderecoDao.ConsultaPorIdCliente(Convert.ToInt32(HttpContext.Session.GetString("Id")));
            ViewBag.listaEnderecos = endereco;

            return View("Conta", cliente);
        }

        protected virtual void PreencheDadosParaView(string operacao, T model)
        {
            if (GeraProximoId && operacao == "I")
                model.id = DAO.ProximoId();
        }

        public IActionResult Salvar(T model, string operacao, string? confsenha, string? confemail)
        {
            ModelState.Clear();
            try
            {
                ValidaDados(model, operacao, confsenha, confemail);
                if (ModelState.IsValid == false)
                {
                    ViewBag.operacao = operacao;
                    PreencheDadosParaView(operacao, model);
                    return View("Form", model);
                }
                else
                {
                    if (operacao == "I")
                        DAO.Insert(model);
                    else
                        DAO.Update(model);
                    return RedirectToAction("Index", "Home");
                }
            }
            catch (Exception erro)
            {
                ViewBag.Erro = "Ocorreu um erro: " + erro.Message;
                ViewBag.operacao = operacao;
                PreencheDadosParaView(operacao, model);
                return View("Form", model);
            }
        }

        protected virtual void ValidaDados(T model, string operacao, string? confsenha, string? confemail)
        {
            if (operacao == "I" && DAO.Consulta(model.id) != null)
                ModelState.AddModelError("Id", "Código já está em uso!");
            if (operacao == "A" && DAO.Consulta(model.id) == null)
                ModelState.AddModelError("Id", "Este registro não existe!");
            if (model.id <= 0)
                ModelState.AddModelError("Id", "Id inválido!");
        }

        public IActionResult Edit(int id)
        {
            try
            {
                ViewBag.operacao = "A";
                var model = DAO.Consulta(id);
                if (model == null)
                    return RedirectToAction("index");
                else
                {
                    PreencheDadosParaView("A", model);
                    return View("Form", model);
                }
            }
            catch
            {
                return RedirectToAction("index");
            }
        }

        public IActionResult Delete(int id)
        {
            try
            {
                DAO.Delete(id);
                return RedirectToAction("Index", "Home");
            }
            catch
            {
                return RedirectToAction("Index", "Home");
            }
        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            ViewBag.Logado = HelperControllers.VerificaUserLogado(HttpContext.Session);
            if (ViewBag.Logado == true)
            {
                ViewBag.IdLogado = Convert.ToInt32(HttpContext.Session.GetString("Id"));
                ClienteViewModel clienteConectado = new ClienteViewModel();
                clienteConectado = HelperControllers.ClienteConectado(ViewBag.IdLogado);
                ViewBag.NomeLogado = clienteConectado.nome;
            }
        }

        public IActionResult Entrar()
        {
            return View("Entrar");
        }
        public IActionResult VerificaLogin(string email, string senha)
        {

            LoginDAO dao = new LoginDAO();
            var logins = dao.Listagem();

            foreach (LoginViewModel login in logins)
            {
                if (email == login.email && senha == login.senha)
                {
                    HttpContext.Session.SetString("Logado", "true");
                    HttpContext.Session.SetString("Id", login.id.ToString());
                    return RedirectToAction("index", "Home");
                }
                
            }
            ViewBag.Erro = "Usuário ou senha inválidos!";
            return View("Entrar");

        }


        public IActionResult LogOff()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Entrar");
        }
    }
    
}