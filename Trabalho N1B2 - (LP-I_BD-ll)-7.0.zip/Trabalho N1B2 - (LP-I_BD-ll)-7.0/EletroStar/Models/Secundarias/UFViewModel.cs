﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EletroStar.Models.Secundarias
{
    public class UFViewModel : PadraoViewModel
    {
        public string descricao { get; set; }
    }
}
