﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EletroStar.Models.Secundarias
{
    public class PagamentoViewModel : PadraoViewModel
    {
        public string descricao { get; set; }
    }
}
