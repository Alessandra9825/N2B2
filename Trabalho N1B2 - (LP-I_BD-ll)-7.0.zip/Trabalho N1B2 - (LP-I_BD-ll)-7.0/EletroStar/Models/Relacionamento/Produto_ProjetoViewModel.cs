﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EletroStar.Models.Relacionamento
{
    public class Produto_ProjetoViewModel : PadraoViewModel
    {
        public int id_Produto { get; set;}

        public int id_Projeto { get; set;}
    }
}
