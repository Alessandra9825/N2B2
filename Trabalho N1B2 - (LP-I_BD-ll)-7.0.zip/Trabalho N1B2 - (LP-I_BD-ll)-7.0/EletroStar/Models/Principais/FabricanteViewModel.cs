﻿using EletroStar.DAO.Principais;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EletroStar.Models.Principais
{
    public class FabricanteViewModel: PadraoViewModel
    {
        public string nome { get; set; }
    }
}
