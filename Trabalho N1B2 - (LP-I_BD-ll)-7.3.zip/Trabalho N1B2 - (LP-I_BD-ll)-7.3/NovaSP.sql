USE [Portal]

CREATE PROCEDURE spConsultaPorId_Cliente (
    @id INT,
    @tabela VARCHAR(100)) AS
BEGIN
    DECLARE @sql VARCHAR(100) = 'SELECT * FROM ' + @tabela + ' WHERE id_Cliente = ' + CAST(@id AS VARCHAR(MAX))
	EXEC(@sql)
END
GO

CREATE PROCEDURE spConsultaPorId_Carrinho (
    @id INT,
    @tabela VARCHAR(100)) AS
BEGIN
    DECLARE @sql VARCHAR(100) = 'SELECT * FROM ' + @tabela + ' WHERE id_Carrinho = ' + CAST(@id AS VARCHAR(MAX))
	EXEC(@sql)
END
GO

CREATE PROCEDURE spInsert_Carrinho_Produto (
    @id INT,
    @id_Carrinho INT,
    @id_Produto INT, 
    @quantidade INT) AS
BEGIN
    INSERT INTO Carrinho_Produto(id_Carrinho, id_Produto, quantidade) 
        VALUES(@id_Carrinho, @id_Produto, @quantidade)
END
GO