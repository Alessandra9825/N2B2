﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EletroStar.DAO;
using EletroStar.Models;
using Microsoft.AspNetCore.Mvc;

namespace EletroStar.Controllers
{
    public class PedidoController : PadraoController<PedidoViewModel>
    {
        public IActionResult Adicionar(PedidoViewModel model)
        {
            PedidoDAO dao = new PedidoDAO();
            model.id = dao.ProximoId();
            dao.Insert(model);
            return View();
        }
    }
}