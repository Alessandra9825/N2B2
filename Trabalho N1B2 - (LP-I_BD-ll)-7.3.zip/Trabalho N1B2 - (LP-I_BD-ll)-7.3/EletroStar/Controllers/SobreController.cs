﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using EletroStar.Models;
using Microsoft.AspNetCore.Http;

namespace EletroStar.Controllers
{
    public class SobreController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.Logado = HelperControllers.VerificaUserLogado(HttpContext.Session);
            if (ViewBag.Logado == true)
            {
                ViewBag.IdLogado = Convert.ToInt32(HttpContext.Session.GetString("Id"));
                ClienteViewModel clienteConectado = new ClienteViewModel();
                clienteConectado = HelperControllers.ClienteConectado(ViewBag.IdLogado);
                ViewBag.NomeLogado = clienteConectado.nome;
            }
            return View();
        }
    }
}