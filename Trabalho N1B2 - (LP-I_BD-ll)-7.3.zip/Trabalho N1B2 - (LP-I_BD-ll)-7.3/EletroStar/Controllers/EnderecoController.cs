﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EletroStar.DAO;
using EletroStar.DAO.Secundarias;
using EletroStar.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace EletroStar.Controllers
{
    public class EnderecoController : PadraoController<EnderecoViewModel>
    {
        public EnderecoController()
        {
            DAO = new EnderecoDAO();
            GeraProximoId = true;
        }

        protected override void PreencheDadosParaView(string operacao, EnderecoViewModel model)
        {
            //utiliza os dados do pai
            base.PreencheDadosParaView(operacao, model);

            UFDAO dao = new UFDAO();
            var ufs = dao.Listagem();
            List<SelectListItem> listaUFS = new List<SelectListItem>();
            listaUFS.Add(new SelectListItem("Selecione seu Estado", "0"));

            foreach (var uf in ufs)
			{
                SelectListItem item = new SelectListItem(uf.descricao, uf.id.ToString());
                listaUFS.Add(item);
            }

            ViewBag.UF = listaUFS;


        }


        protected override void ValidaDados(EnderecoViewModel model, string operacao, string? confsenha, string? confemail)
        {
            //utiliza a heranca para validar dados iguais
            base.ValidaDados(model, operacao, confsenha, confemail);

            if (string.IsNullOrEmpty(model.rua))
                ModelState.AddModelError("rua", "Preencha o nome da rua.");
            if (model.numero <= 0)
                ModelState.AddModelError("numero", "Preencha um número válido.");
            if (string.IsNullOrEmpty(model.bairro))
                ModelState.AddModelError("bairro", "Preencha o nome do bairro.");
            if (string.IsNullOrEmpty(model.cidade))
                ModelState.AddModelError("cidade", "Preencha o nome da cidade");
            if (model.id_UF <= 0)
                ModelState.AddModelError("id_UF", "Escolha um estado válido");
            if (string.IsNullOrEmpty(model.cep))
                ModelState.AddModelError("cep", "Preencha o CEP");
            if (string.IsNullOrEmpty(model.pais))
                ModelState.AddModelError("pais", "Preencha um Pais válido");
            if (string.IsNullOrEmpty(model.complemento))
                model.complemento = "";
            model.id_Cliente = Convert.ToInt32(HttpContext.Session.GetString("Id"));
        }
    }
}