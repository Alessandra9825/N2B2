﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EletroStar.Models;
using EletroStar.DAO.Principais;
using EletroStar.DAO;

namespace EletroStar.Controllers
{
	public class HelperControllers
	{
		public static Boolean VerificaUserLogado(ISession session)
		{
			string logado = session.GetString("Logado");
			if (logado == null)
				return false;
			else
				return true;
		}

		public static ClienteViewModel ClienteConectado(int id)
		{
			ClienteDAO dao = new ClienteDAO();
			var login = dao.Consulta(id);
			return login;
		}
	}
}

