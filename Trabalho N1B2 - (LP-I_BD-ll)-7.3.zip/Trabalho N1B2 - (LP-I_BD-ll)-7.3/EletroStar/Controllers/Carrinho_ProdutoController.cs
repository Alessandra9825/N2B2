﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EletroStar.DAO.Principais;
using EletroStar.DAO.Relacionamento;
using EletroStar.Models;
using EletroStar.Models.Relacionamento;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EletroStar.Controllers
{
	public class Carrinho_ProdutoController : PadraoController<Carrinho_ProdutoViewModel>
	{
        public IActionResult Adicionar(int id, int quant)
        {
            try
            {
                ViewBag.Logado = HelperControllers.VerificaUserLogado(HttpContext.Session);
                if (ViewBag.Logado == true)
                {
                    ViewBag.IdLogado = Convert.ToInt32(HttpContext.Session.GetString("Id"));
                    ClienteViewModel clienteConectado = new ClienteViewModel();
                    clienteConectado = HelperControllers.ClienteConectado(ViewBag.IdLogado);
                    ViewBag.NomeLogado = clienteConectado.nome;
                }
                Carrinho_ProdutoViewModel model = Activator.CreateInstance(typeof(Carrinho_ProdutoViewModel)) as Carrinho_ProdutoViewModel;
                model.id_Produto = id;
                model.quantidade = quant;
                Carrinho_Produto cpDao = new Carrinho_Produto();
                model.id = cpDao.ProximoId();

                CarrinhoDAO cDao = new CarrinhoDAO();
                List<CarrinhoViewModel> listaDeCarrinhos = cDao.ConsultaPorIdCliente(ViewBag.IdLogado);
                int ultimoCarrinho = 0;
                CarrinhoViewModel carrinhoUtilizado = new CarrinhoViewModel();
                foreach (CarrinhoViewModel carrinho in listaDeCarrinhos)
                {
                    if (ultimoCarrinho < carrinho.id)
                    {
                        ultimoCarrinho = carrinho.id;
                        carrinhoUtilizado = carrinho;
                    }
                }
                model.id_Carrinho = ultimoCarrinho;
                cpDao.Insert(model);
                return RedirectToAction("Index", "Comprar");
            }
			catch
			{
                return RedirectToAction("Index", "Comprar");
			}
        }

        public IActionResult Remover(int id)
        {
            ViewBag.Logado = HelperControllers.VerificaUserLogado(HttpContext.Session);
            if (ViewBag.Logado == true)
            {
                ViewBag.IdLogado = Convert.ToInt32(HttpContext.Session.GetString("Id"));
                ClienteViewModel clienteConectado = new ClienteViewModel();
                clienteConectado = HelperControllers.ClienteConectado(ViewBag.IdLogado);
                ViewBag.NomeLogado = clienteConectado.nome;
            }
            Carrinho_Produto cpDao = new Carrinho_Produto();
            cpDao.Delete(id);
            return RedirectToAction("Index", "Carrinho");
        }
    }
}
