﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EletroStar.DAO;
using EletroStar.DAO.Principais;
using EletroStar.DAO.Relacionamento;
using EletroStar.Models;
using EletroStar.Models.Relacionamento;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace EletroStar.Controllers
{
	public class CarrinhoController : Controller
	{
		public IActionResult Index()
		{
			ViewBag.Logado = HelperControllers.VerificaUserLogado(HttpContext.Session);
			if (ViewBag.Logado == true)
			{
				ViewBag.IdLogado = Convert.ToInt32(HttpContext.Session.GetString("Id"));
				ClienteViewModel clienteConectado = new ClienteViewModel();
				clienteConectado = HelperControllers.ClienteConectado(ViewBag.IdLogado);
				ViewBag.NomeLogado = clienteConectado.nome;
			}
			CarrinhoDAO cDao = new CarrinhoDAO();
			List<CarrinhoViewModel> listaDeCarrinhos = new List<CarrinhoViewModel>();
			listaDeCarrinhos = cDao.ConsultaPorIdCliente(ViewBag.IdLogado);
			if (listaDeCarrinhos.Count == 0)
			{
				CarrinhoViewModel model = Activator.CreateInstance(typeof(CarrinhoViewModel)) as CarrinhoViewModel; //new Model();
				model.id = cDao.ProximoId();
				model.id_Cliente = Convert.ToInt32(HttpContext.Session.GetString("Id"));
				cDao.Insert(model);
			}

			int ultimoCarrinho = 0;
			CarrinhoViewModel carrinhoUtilizado = new CarrinhoViewModel();
			foreach (CarrinhoViewModel carrinho in listaDeCarrinhos)
			{
				if (ultimoCarrinho < carrinho.id)
				{
					ultimoCarrinho = carrinho.id;
					carrinhoUtilizado = carrinho;
				}
			}


			Carrinho_Produto cpDao = new Carrinho_Produto();
			List<Carrinho_ProdutoViewModel> listaDeCarrinhoProdutos = cpDao.ConsultaPorIdCarrinho(carrinhoUtilizado.id);
			ViewBag.listaCarrinhoProdutos = listaDeCarrinhoProdutos;
			ProdutoDAO pDao = new ProdutoDAO();
			List<ProdutoViewModel> listaDeProdutos = new List<ProdutoViewModel>();
			foreach (Carrinho_ProdutoViewModel carrinhoProduto in listaDeCarrinhoProdutos)
			{
				listaDeProdutos.Add(pDao.Consulta(carrinhoProduto.id_Produto));
			}
			ViewBag.listaProdutos = listaDeProdutos;


			return View("Index");
		}

		public IActionResult Detalhes()
		{
			ViewBag.Logado = HelperControllers.VerificaUserLogado(HttpContext.Session);
			if (ViewBag.Logado == true)
			{
				ViewBag.IdLogado = Convert.ToInt32(HttpContext.Session.GetString("Id"));
				ClienteViewModel clienteConectado = new ClienteViewModel();
				clienteConectado = HelperControllers.ClienteConectado(ViewBag.IdLogado);
				ViewBag.NomeLogado = clienteConectado.nome;
			}
			CarrinhoDAO cDao = new CarrinhoDAO();
			List<CarrinhoViewModel> listaDeCarrinhos = new List<CarrinhoViewModel>();
			listaDeCarrinhos = cDao.ConsultaPorIdCliente(ViewBag.IdLogado);
			if (listaDeCarrinhos.Count == 0)
			{
				CarrinhoViewModel model = Activator.CreateInstance(typeof(CarrinhoViewModel)) as CarrinhoViewModel; //new Model();
				model.id = cDao.ProximoId();
				model.id_Cliente = Convert.ToInt32(HttpContext.Session.GetString("Id"));
				cDao.Insert(model);
			}

			int ultimoCarrinho = 0;
			CarrinhoViewModel carrinhoUtilizado = new CarrinhoViewModel();
			foreach (CarrinhoViewModel carrinho in listaDeCarrinhos)
			{
				if (ultimoCarrinho < carrinho.id)
				{
					ultimoCarrinho = carrinho.id;
					carrinhoUtilizado = carrinho;
				}
			}


			Carrinho_Produto cpDao = new Carrinho_Produto();
			List<Carrinho_ProdutoViewModel> listaDeCarrinhoProdutos = cpDao.ConsultaPorIdCarrinho(carrinhoUtilizado.id);
			ViewBag.listaCarrinhoProdutos = listaDeCarrinhoProdutos;
			ProdutoDAO pDao = new ProdutoDAO();
			List<ProdutoViewModel> listaDeProdutos = new List<ProdutoViewModel>();
			foreach (Carrinho_ProdutoViewModel carrinhoProduto in listaDeCarrinhoProdutos)
			{
				listaDeProdutos.Add(pDao.Consulta(carrinhoProduto.id_Produto));
			}
			ViewBag.listaProdutos = listaDeProdutos;

			ClienteDAO dao = new ClienteDAO();
			ClienteViewModel cliente = dao.Consulta(Convert.ToInt32(HttpContext.Session.GetString("Id")));
			EnderecoDAO enderecoDao = new EnderecoDAO();
			List<EnderecoViewModel> endereco = enderecoDao.ConsultaPorIdCliente(Convert.ToInt32(HttpContext.Session.GetString("Id")));
			ViewBag.listaEnderecos = endereco;

			return View("Detalhes", cliente);
		}

		public IActionResult Imprimir()
		{
			ViewBag.Logado = HelperControllers.VerificaUserLogado(HttpContext.Session);
			if (ViewBag.Logado == true)
			{
				ViewBag.IdLogado = Convert.ToInt32(HttpContext.Session.GetString("Id"));
				ClienteViewModel clienteConectado = new ClienteViewModel();
				clienteConectado = HelperControllers.ClienteConectado(ViewBag.IdLogado);
				ViewBag.NomeLogado = clienteConectado.nome;
			}
			CarrinhoDAO cDao = new CarrinhoDAO();
			List<CarrinhoViewModel> listaDeCarrinhos = new List<CarrinhoViewModel>();
			listaDeCarrinhos = cDao.ConsultaPorIdCliente(ViewBag.IdLogado);
			if (listaDeCarrinhos.Count == 0)
			{
				CarrinhoViewModel model = Activator.CreateInstance(typeof(CarrinhoViewModel)) as CarrinhoViewModel; //new Model();
				model.id = cDao.ProximoId();
				model.id_Cliente = Convert.ToInt32(HttpContext.Session.GetString("Id"));
				cDao.Insert(model);
			}

			int ultimoCarrinho = 0;
			CarrinhoViewModel carrinhoUtilizado = new CarrinhoViewModel();
			foreach (CarrinhoViewModel carrinho in listaDeCarrinhos)
			{
				if (ultimoCarrinho < carrinho.id)
				{
					ultimoCarrinho = carrinho.id;
					carrinhoUtilizado = carrinho;
				}
			}


			Carrinho_Produto cpDao = new Carrinho_Produto();
			List<Carrinho_ProdutoViewModel> listaDeCarrinhoProdutos = cpDao.ConsultaPorIdCarrinho(carrinhoUtilizado.id);
			ViewBag.listaCarrinhoProdutos = listaDeCarrinhoProdutos;
			ProdutoDAO pDao = new ProdutoDAO();
			List<ProdutoViewModel> listaDeProdutos = new List<ProdutoViewModel>();
			foreach (Carrinho_ProdutoViewModel carrinhoProduto in listaDeCarrinhoProdutos)
			{
				listaDeProdutos.Add(pDao.Consulta(carrinhoProduto.id_Produto));
			}
			ViewBag.listaProdutos = listaDeProdutos;

			ClienteDAO dao = new ClienteDAO();
			ClienteViewModel cliente = dao.Consulta(Convert.ToInt32(HttpContext.Session.GetString("Id")));
			EnderecoDAO enderecoDao = new EnderecoDAO();
			List<EnderecoViewModel> endereco = enderecoDao.ConsultaPorIdCliente(Convert.ToInt32(HttpContext.Session.GetString("Id")));
			ViewBag.listaEnderecos = endereco;

			return View("Imprimir", cliente);
		}
	}
}

