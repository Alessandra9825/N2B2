﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EletroStar.Models.Principais
{
    public class ImagensViewModel : PadraoViewModel
    {
        public string imagem { get; set; }
        public int id_Produto { get; set; }        
    }
}
