﻿using EletroStar.Models.Principais;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace EletroStar.DAO.Principais
{
	public class LoginDAO : PadraoDAO<LoginViewModel>
	{
		protected override SqlParameter[] CriaParametros(LoginViewModel model)
		{
			SqlParameter[] parametros =
			{
				new SqlParameter("id", model.id),
				new SqlParameter("email", model.email),
				new SqlParameter("senha", model.senha)
			};
			return parametros;
		}
		protected override LoginViewModel MontaModel(DataRow registro)
		{
			LoginViewModel l = new LoginViewModel()
			{
				id = Convert.ToInt32(registro["id"]),
				email = registro["email"].ToString(),
				senha = registro["senha"].ToString()
			};
			return l;
		}
		protected override void SetTabela()
		{
			Tabela = "cliente";
		}
	}
}
