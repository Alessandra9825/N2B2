USE [master]
GO

CREATE DATABASE [Portal]
GO

USE [Portal]
go

                                    --Tabelas

--TABELAS PRINCIPAIS
CREATE TABLE [Cliente] (
	id INT IDENTITY(1, 1) PRIMARY KEY,	
    cpf VARCHAR(14) NOT NULL UNIQUE,
    nome VARCHAR(100) NOT NULL, 
    id_EstadoCivil INT NOT NULL,
    email VARCHAR(100),
    nascimento DATETIME NOT NULL, 
    genero CHAR(1) NOT NULL,
    tel_residencial VARCHAR(15),
    tel_celular VARCHAR(16),    
    imagem VARBINARY(MAX),
    admin BIT NOT NULL,
    senha VARCHAR(100) NOT NULL)
GO
CREATE TABLE [Endereco] (
    id INT IDENTITY(1, 1) PRIMARY KEY,
    id_Cliente INT,
    rua VARCHAR(100) NOT NULL,
    numero INT NOT NULL, 
    complemento VARCHAR(100),
    bairro VARCHAR(100) NOT NULL,
    cidade VARCHAR(100) NOT NULL, 
    id_UF INT NOT NULL,
    cep VARCHAR(9) NOT NULL,
    pais VARCHAR(100) NOT NULL)
GO
CREATE TABLE [Produto] (
    id INT IDENTITY(1, 1) PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao VARCHAR(MAX) NOT NULL, 
    valor DECIMAL(10, 2) NOT NULL,
    id_Fabricante INT NOT NULL,
    id_Categoria INT NOT NULL,
    imagem VARBINARY(MAX) NOT NULL)
GO
CREATE TABLE [Pedido] (
    id INT IDENTITY(1, 1) PRIMARY KEY,
    id_Cliente INT NOT NULL,
    data DATETIME NOT NULL, 
    valor DECIMAL(10, 2) NOT NULL,
    quantidade INT NOT NULL,
    id_Status INT NOT NULL, 
    prazo INT NOT NULL,
    id_Pagamento INT NOT NULL,
    id_Carrinho INT NOT NULL)
GO
CREATE TABLE [Carrinho] (
    id INT IDENTITY(1, 1) PRIMARY KEY,
    id_Cliente INT UNIQUE, --o cliente so pode possuir um carrinho   
	quantidade INT)
GO
CREATE table [Projeto] (
    id INT IDENTITY(1, 1) PRIMARY KEY,
    nome VARCHAR(100),
    descricao VARCHAR(MAX),
    link VARCHAR(MAX))
GO
CREATE TABLE [Imagens] (
    id INT IDENTITY(1, 1) PRIMARY KEY,
    imagem VARBINARY(MAX),
    id_Produto INT)
GO
CREATE TABLE [Fabricante] (
    id INT IDENTITY(1, 1) PRIMARY KEY,
    nome VARCHAR(100))   
GO


--TABELAS SECUNDARIAS
CREATE TABLE [EstadoCivil] (
    id INT IDENTITY(1, 1) PRIMARY KEY,
    descricao VARCHAR(100))
GO
CREATE TABLE [UF] (
    id INT IDENTITY(1, 1) PRIMARY KEY,
    descricao VARCHAR(100))
GO
CREATE TABLE [Pagamento] (
    id INT IDENTITY(1, 1) PRIMARY KEY,
    descricao VARCHAR(100))
GO
CREATE TABLE [Status] (
    id INT IDENTITY(1, 1) PRIMARY KEY,
    descricao VARCHAR(100))
GO
CREATE TABLE [Categoria] (
    id INT IDENTITY(1, 1) PRIMARY KEY,
    descricao VARCHAR(100))
GO

--TABELAS RELACIONAIS
CREATE TABLE [Carrinho_Produto] (
    id INT IDENTITY(1, 1) PRIMARY KEY,
    id_Carrinho INT,
    id_Produto INT,
    quantidade INT)
GO
CREATE TABLE [Produto_Projeto] (
    id INT IDENTITY(1, 1) PRIMARY KEY,
    id_Produto INT,
    id_Projeto INT)
GO


                                    --Constraints
ALTER TABLE Cliente
ADD CONSTRAINT FK_Cliente_EstadoCivil
FOREIGN KEY (id_EstadoCivil) REFERENCES EstadoCivil (id)
GO

ALTER TABLE Endereco
ADD CONSTRAINT FK_Endereco_UF
FOREIGN KEY (id_UF) REFERENCES UF (id)
GO

ALTER TABLE Endereco
ADD CONSTRAINT FK_Endereco_Cliente
FOREIGN KEY (id_Cliente) REFERENCES Cliente (id)
GO

ALTER TABLE Carrinho_Produto
ADD CONSTRAINT FK_CarrinhoProduto_Carrinho
FOREIGN KEY (id_Carrinho) REFERENCES Carrinho (id)
GO

ALTER TABLE Carrinho_Produto
ADD CONSTRAINT FK_CarrinhoProduto_Produto
FOREIGN KEY (id_Produto) REFERENCES Produto (id)
GO

ALTER TABLE Carrinho
ADD CONSTRAINT FK_Carrinho_Cliente
FOREIGN KEY (id_Cliente) REFERENCES Cliente (id)
GO

ALTER TABLE Pedido
ADD CONSTRAINT FK_Pedido_Cliente
FOREIGN KEY (id_Cliente) REFERENCES Cliente (id)
GO

ALTER TABLE Pedido
ADD CONSTRAINT FK_Pedido_Status
FOREIGN KEY (id_Status) REFERENCES Status (id)
GO

ALTER TABLE Pedido
ADD CONSTRAINT FK_Pedido_Pagamento
FOREIGN KEY (id_Pagamento) REFERENCES Pagamento (id)
GO

ALTER TABLE Pedido
ADD CONSTRAINT FK_Pedido_Carrinho
FOREIGN KEY (id_Carrinho) REFERENCES Carrinho (id)
GO

ALTER TABLE Produto
ADD CONSTRAINT FK_Produto_Fabricante
FOREIGN KEY (id_Fabricante) REFERENCES Fabricante (id)
GO

ALTER TABLE Produto
ADD CONSTRAINT FK_Produto_Categoria
FOREIGN KEY (id_Categoria) REFERENCES Categoria (id)
GO

ALTER TABLE Produto_Projeto
ADD CONSTRAINT FK_ProdutoProjeto_Produto
FOREIGN KEY (id_Produto) REFERENCES Produto (id)
GO

ALTER TABLE Produto_Projeto
ADD CONSTRAINT FK_ProdutoProjeto_Projeto
FOREIGN KEY (id_Projeto) REFERENCES Projeto (id)
GO

ALTER TABLE Imagens
ADD CONSTRAINT FK_Imagens_Produto
FOREIGN KEY (id_Produto) REFERENCES Produto (id)
GO


                                    --Procedures
-- Globais
CREATE OR ALTER PROCEDURE spDelete (
    @id INT,
    @tabela VARCHAR(100))
AS
BEGIN
	DECLARE @sql VARCHAR(100) = 'DELETE ' + @tabela + ' WHERE id = ' + CAST(@id AS VARCHAR(MAX))
	EXEC(@sql)
END
GO

CREATE OR ALTER PROCEDURE spConsulta (
    @id INT,
    @tabela VARCHAR(100)) AS
BEGIN
    DECLARE @sql VARCHAR(100) = 'SELECT * FROM ' + @tabela + ' WHERE id = ' + CAST(@id AS VARCHAR(MAX))
	EXEC(@sql)
END
GO

CREATE OR ALTER PROCEDURE spListagem (
    @tabela VARCHAR(100),
    @ordem VARCHAR(100)) AS
BEGIN
    DECLARE @sql VARCHAR(100) = 'SELECT * FROM ' + @tabela + ' ORDER BY ' + @ordem
	EXEC(@sql)
END
GO

CREATE OR ALTER PROCEDURE spProximoId (
    @tabela VARCHAR(MAX)) AS
BEGIN
    EXEC('SELECT ISNULL(MAX(id)+1, 1) as MAIOR from ' + @tabela)
END
GO

-- Cliente
CREATE OR ALTER PROCEDURE spInsert_Cliente (
    @id INT,
    @cpf VARCHAR(14),
    @nome VARCHAR(100), 
    @id_EstadoCivil INT,
    @email VARCHAR(100),
    @nascimento DATETIME, 
    @genero CHAR(1),
    @tel_residencial VARCHAR(15),
    @tel_celular VARCHAR(16),
    @imagem VARBINARY(MAX),
    @admin BIT,
    @senha VARCHAR(100)) AS
BEGIN
    INSERT INTO Cliente(cpf, nome, id_EstadoCivil, email, nascimento, genero, tel_residencial, tel_celular, imagem, admin, senha) 
        VALUES(@cpf, @nome, @id_EstadoCivil, @email, @nascimento, @genero, @tel_residencial, @tel_celular, @imagem, @admin, @senha)
END
GO

CREATE OR ALTER PROCEDURE spUpdate_Cliente (
    @id INT,
    @cpf VARCHAR(14),
    @nome VARCHAR(100), 
    @id_EstadoCivil INT,
    @email VARCHAR(100),
    @nascimento DATETIME, 
    @genero CHAR(1),
    @tel_residencial VARCHAR(15),
    @tel_celular VARCHAR(16),
    @imagem VARBINARY(MAX),
    @admin BIT,
    @senha VARCHAR(100)) AS
BEGIN
    UPDATE Cliente SET
        cpf = @cpf, 
        nome = @nome, 
        id_EstadoCivil = @id_EstadoCivil, 
        email = @email,          
        nascimento = @nascimento, 
        genero = @genero, 
        tel_residencial = @tel_residencial,
        tel_celular = @tel_celular,        
        imagem = @imagem,
        admin = @admin,
        senha = @senha
        WHERE id = @id
END
GO

--Endereco
CREATE OR ALTER PROCEDURE spInsert_Endereco (
    @id INT,
    @id_Cliente INT,
    @rua VARCHAR(100),
    @numero INT, 
    @complemento VARCHAR(100),
    @bairro VARCHAR(100),
    @cidade VARCHAR(100), 
    @id_UF INT,
    @cep VARCHAR(9),
    @pais VARCHAR(100)) AS
BEGIN
    INSERT INTO Endereco(id_Cliente, rua, numero, complemento, bairro, cidade, id_UF, cep, pais) 
        VALUES(@id_Cliente, @rua, @numero, @complemento, @bairro, @cidade, @id_UF, @cep, @pais)
END
GO

CREATE OR ALTER PROCEDURE spUpdate_Endereco (
    @id INT,
    @id_Cliente INT,
    @rua VARCHAR(100),
    @numero INT, 
    @complemento VARCHAR(100),
    @bairro VARCHAR(100),
    @cidade VARCHAR(100), 
    @id_UF INT,
    @cep VARCHAR(9),
    @pais VARCHAR(100)) AS
BEGIN
    UPDATE Endereco SET
        id_Cliente = @id_Cliente,
        rua = @rua, 
        numero = @numero, 
        complemento = @complemento, 
        bairro = @bairro, 
        cidade = @cidade, 
        id_UF = @id_UF, 
        cep = @cep, 
        pais = @pais
        WHERE id = @id
END
GO

-- Produto
CREATE OR ALTER PROCEDURE spInsert_Produto (
    @id INT,
    @nome VARCHAR(100),
    @descricao VARCHAR(MAX),
    @valor DECIMAL(10, 2),
    @id_Fabricante INT,
    @id_Categoria INT,
    @imagem varbinary(max)) AS
BEGIN
    INSERT INTO Produto (nome, descricao, valor, id_Fabricante, id_Categoria,imagem)
        VALUES(@nome, @descricao, @valor, @id_Fabricante, @id_Categoria,@imagem)
END
GO

CREATE OR ALTER PROCEDURE spUpdate_Produto (
    @id INT,
    @nome VARCHAR(100),
    @descricao VARCHAR(MAX),
    @valor DECIMAL(10, 2),
    @id_Fabricante INT,
    @id_Categoria INT,
    @imagem varbinary(max)) AS
BEGIN
    UPDATE Produto SET
        nome = @nome, 
        descricao = @descricao, 
        valor = @valor, 
        id_Fabricante = @id_Fabricante, 
        id_Categoria = @id_Categoria,
        imagem = @imagem         
        WHERE id = @id
END
GO

-- Pedido
CREATE OR ALTER PROCEDURE spInsert_Pedido (
    @id INT,
    @id_Cliente INT,
    @data DATETIME, 
    @valor DECIMAL(10, 2),
    @quantidade INT,
    @id_Status INT,  
    @prazo INT,
    @id_Pagamento INT,
    @id_Carrinho INT) AS
BEGIN
    INSERT INTO Pedido(id_Cliente, data, valor, quantidade, id_Status, prazo, id_Pagamento, id_Carrinho) 
        VALUES(@id_Cliente, @data, @valor, @quantidade, @id_Status, @prazo, @id_Pagamento, @id_Carrinho) 
END
GO

CREATE OR ALTER PROCEDURE spUpdate_Pedido (
    @id INT,
    @id_Cliente INT,
    @data DATETIME, 
    @valor DECIMAL(10, 2),
    @quantidade INT,
    @id_Status INT,  
    @prazo INT,
    @id_Pagamento INT,
    @id_Carrinho INT) AS
BEGIN
    UPDATE Pedido SET
        id_Cliente = @id_Cliente, 
        data = @data, 
        valor = @valor, 
        quantidade = @quantidade, 
        id_Status = @id_Status, 
        prazo = @prazo, 
        id_Pagamento = @id_Pagamento, 
        id_Carrinho = @id_Carrinho
        WHERE id = @id
END
GO

--Fabricante
CREATE OR ALTER PROCEDURE spInsert_Fabricante (
    @id INT,
    @nome VARCHAR(100)) AS
BEGIN
    INSERT INTO Fabricante(nome) 
        VALUES(@nome)
END
GO

CREATE OR ALTER PROCEDURE spUpdate_Fabricante (
    @id INT,
    @nome VARCHAR(100)) AS
BEGIN
    UPDATE Fabricante SET
        nome = @nome         
        WHERE id = @id
END
GO

--Carrinho
CREATE OR ALTER PROCEDURE spInsert_Carrinho (
    @id INT,
    @id_cliente INT) AS
BEGIN
    INSERT INTO Carrinho(id_cliente) 
        VALUES(@id_cliente)
END
GO

CREATE OR ALTER PROCEDURE spUpdate_Carrinho (
    @id INT,
    @id_cliente INT) AS
BEGIN
    Update Carrinho SET
        id_cliente = @id_cliente
    WHERE id = @id    
END
GO

--Projeto
CREATE OR ALTER PROCEDURE spInsert_Projeto (
    @id INT,
    @nome VARCHAR(100),
    @descricao VARCHAR(MAX),
    @link VARCHAR(MAX)) AS
BEGIN
    INSERT INTO Projeto (nome, descricao, link) 
        VALUES(@nome, @descricao, @link)
END
GO

CREATE OR ALTER PROCEDURE spUpdate_Projeto (
    @id INT,
    @nome VARCHAR(100),
    @descricao VARCHAR(MAX),
    @link VARCHAR(MAX)) AS
BEGIN
    Update Projeto SET
        nome = @nome,
        descricao = @descricao,
        link = @link
    WHERE id = @id
END
GO

--triggers de validacao

CREATE OR ALTER TRIGGER trg_upCarrinhoProduto
on Carrinho_Produto
INSTEAD OF INSERT, UPDATE AS
BEGIN
    if(select count(*) from inserted) > 1
	begin	
		rollback tran
		return
	end

	declare @id_Carrinho INT = (SELECT id_Carrinho FROM inserted)
	declare @id_Produto INT = (SELECT id_Produto FROM inserted)
	declare @quantidade INT = (SELECT quantidade FROM inserted)

    if(SELECT count(*) FROM Carrinho_Produto WHERE id_Carrinho = @id_Carrinho and id_Produto = @id_Produto) > 1
        UPDATE Carrinho_Produto
            SET quantidade = @quantidade
            WHERE id_Carrinho = @id_Carrinho and id_Produto = @id_Produto    

    INSERT INTO Carrinho_Produto (id_Carrinho, id_Produto, quantidade)
        SELECT i.id_Carrinho, i.id_Produto, i.quantidade FROM inserted i

    return
END
GO

--Inserts 

INSERT INTO EstadoCivil(descricao)
VALUES('Solteiro(a)'),
      ('Casado(a)'),
	  ('Separado(a)'),
	  ('Divorciado(a)'),
	  ('Viúvo(a)')
GO

INSERT INTO UF(descricao)
VALUES('Acre'),
      ('Alagoas'),
	  ('Amazonas'),
	  ('Amapá'),
      ('Bahia'),
	  ('Ceará'),
	  ('Distrito Federal'),
      ('Espírito Santo'),
	  ('Goias'),
	  ('Maranhão'),
      ('Minas Gerais'),
	  ('Mato Grosso do Sul'),
	  ('Mato Grosso'),
      ('Pará'),
	  ('Paraíba'),
	  ('Pernambuco'),
      ('Piauí'),
	  ('Paraná'),
	  ('Rio de Janeiro'),
      ('Rio Grande do Norte'),
	  ('Rondônia'),
	  ('Roraima'),
      ('Rio Grande do Sul'),
	  ('Santa Catarina'),
	  ('Sergipe'),
      ('São Paulo'),
	  ('Tocantins')
GO

INSERT INTO Pagamento(descricao)
VALUES('Cartão Crédito/Débito'),
      ('Boleto Bancário'),
      ('Débito em Conta'),
      ('Depósito'),
      ('Gateway de Pagamento'),
      ('Paypal'),
      ('PagSeguro'),
      ('Mercado Pago')
GO

INSERT INTO Categoria(descricao)
VALUES('Placas'),
      ('Componente'),
      ('Importados')      
GO

INSERT INTO Fabricante(nome)
VALUES('MadeInChina'),
      ('MadeInBrazil'),
      ('Made')      
GO

insert into Cliente values ('cpf', 'nome', 1, 'email', '1990-09-05', 'M', 'tel_res', 'tel_cel', null, 0, 'senha')
